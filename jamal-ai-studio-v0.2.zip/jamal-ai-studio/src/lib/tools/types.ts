export type ToolRisk = "read" | "write" | "external" | "compute";

export type ToolDefinition = {
  id: string;
  name: string;
  description: string;
  inputSchema: Record<string, unknown>;
  risk: ToolRisk;
  enabled: boolean;
  requiresApproval: boolean;
};

export type ToolInvocation = {
  toolId: string;
  input: Record<string, unknown>;
  userId: string;
  taskId: string;
};
