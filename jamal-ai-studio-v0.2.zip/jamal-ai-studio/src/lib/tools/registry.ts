import type { ToolDefinition } from "./types";

/** Static safe registry for MVP. Dynamic installation comes after auth + sandboxing. */
const tools: ToolDefinition[] = [
  {
    id: "remotion.create_project",
    name: "Create Remotion project",
    description: "Prepare a video composition project in an isolated worker.",
    inputSchema: { type: "object", properties: { brief: { type: "string" } }, required: ["brief"] },
    risk: "compute",
    enabled: false,
    requiresApproval: true
  },
  {
    id: "github.create_repository",
    name: "Create GitHub repository",
    description: "Create a repository using a user-authorized GitHub installation.",
    inputSchema: { type: "object", properties: { name: { type: "string" }, private: { type: "boolean" } }, required: ["name"] },
    risk: "external",
    enabled: false,
    requiresApproval: true
  }
];

export function listTools() {
  return tools;
}

export function getTool(id: string) {
  return tools.find(tool => tool.id === id && tool.enabled);
}
