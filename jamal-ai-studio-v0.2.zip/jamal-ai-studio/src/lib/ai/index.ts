import type { AIProvider, ProviderId } from "./types";

/**
 * Provider adapter placeholder.
 * Implement each provider using its official server-side SDK.
 * Never send provider secrets to client components.
 */
export function getConfiguredProvider(): ProviderId | null {
  const id = process.env.AI_PROVIDER;
  if (id === "openai" || id === "anthropic" || id === "google") return id;
  return null;
}

export function assertProviderConfigured(): AIProvider {
  throw new Error(
    "AI provider adapter is not configured yet. Add a server-side provider implementation before enabling live AI."
  );
}
