export type ProviderId = "openai" | "anthropic" | "google";

export type ChatMessage = {
  role: "system" | "user" | "assistant";
  content: string;
};

export type AIResult = {
  text: string;
  provider: ProviderId;
  model: string;
};

export interface AIProvider {
  id: ProviderId;
  generate(messages: ChatMessage[]): Promise<AIResult>;
}
