import type { ToolDefinition } from "@/lib/tools/types";

export type ApprovalDecision = "approved" | "rejected" | "pending";

export function requiresApproval(tool: ToolDefinition): boolean {
  // Fail closed: every write, external side effect, or compute job requires approval.
  return tool.requiresApproval || ["write", "external", "compute"].includes(tool.risk);
}

export function canExecute(decision: ApprovalDecision): boolean {
  return decision === "approved";
}
