import { NextResponse } from "next/server";
import { z } from "zod";

export const runtime = "nodejs";

const RequestSchema = z.object({
  prompt: z.string().trim().min(4).max(12000)
});

const PlanSchema = z.object({
  title: z.string(),
  summary: z.string(),
  steps: z.array(z.object({
    title: z.string(),
    description: z.string(),
    tool: z.string().optional(),
    approvalRequired: z.boolean()
  })).min(1).max(12),
  questions: z.array(z.string()).max(5).default([])
});

const SYSTEM_PROMPT = `أنت المخطط التقني في Jamal AI Studio، مساعد برمجي عربي.
حلّل طلب المستخدم وضع خطة تنفيذ واقعية ومختصرة باللغة العربية.
لا تدّعِ أنك نفذت أي شيء. لا تقترح تنفيذ أوامر مدمرة أو رفع ملفات أو نشر أو دفع تغييرات إلى GitHub دون موافقة صريحة.
ميّز بين التحليل والكتابة والتشغيل والاتصال بخدمات خارجية. كل خطوة تغيّر ملفات أو تشغّل كوداً أو تتصل بخدمة خارجية يجب أن يكون approvalRequired=true.
إذا كان الطلب غامضاً، اذكر أسئلة توضيحية قليلة.
أعد JSON صالحاً فقط بهذا الشكل:
{"title":"...","summary":"...","steps":[{"title":"...","description":"...","tool":"...","approvalRequired":true}],"questions":[]}`;

export async function POST(request: Request) {
  const baseUrl = process.env.AI_BASE_URL?.trim().replace(/\/$/, "");
  const model = process.env.AI_MODEL?.trim();
  const apiKey = process.env.AI_API_KEY?.trim();

  if (!baseUrl || !model) {
    return NextResponse.json({
      error: "engine_not_configured",
      message: "محرك الذكاء لم يُربط بعد. أضف AI_BASE_URL وAI_MODEL في إعدادات الخادم لتفعيل التخطيط الحقيقي."
    }, { status: 503 });
  }

  const rawBody = await request.json().catch(() => null);
  const parsed = RequestSchema.safeParse(rawBody);
  if (!parsed.success) {
    return NextResponse.json({ error: "invalid_request", message: "اكتب مهمة من 4 إلى 12000 حرف." }, { status: 400 });
  }

  try {
    const response = await fetch(`${baseUrl}/chat/completions`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        ...(apiKey ? { Authorization: `Bearer ${apiKey}` } : {})
      },
      body: JSON.stringify({
        model,
        temperature: 0.2,
        response_format: { type: "json_object" },
        messages: [
          { role: "system", content: SYSTEM_PROMPT },
          { role: "user", content: parsed.data.prompt }
        ]
      }),
      signal: AbortSignal.timeout(45000)
    });

    if (!response.ok) {
      const detail = await response.text().catch(() => "");
      console.error("AI gateway error", response.status, detail.slice(0, 500));
      return NextResponse.json({ error: "provider_error", message: "تعذر على مزود النموذج إكمال الطلب. تحقق من إعدادات المحرك وسجلات الخادم." }, { status: 502 });
    }

    const payload = await response.json();
    const content = payload?.choices?.[0]?.message?.content;
    if (typeof content !== "string") {
      return NextResponse.json({ error: "invalid_provider_response", message: "وصل رد غير متوقع من مزود الذكاء." }, { status: 502 });
    }

    const cleaned = content.replace(/^```(?:json)?\s*/i, "").replace(/\s*```$/, "");
    const plan = PlanSchema.safeParse(JSON.parse(cleaned));
    if (!plan.success) {
      return NextResponse.json({ error: "invalid_plan", message: "لم ينتج النموذج خطة بالصيغة المطلوبة. جرّب صياغة الطلب بشكل أوضح." }, { status: 502 });
    }

    return NextResponse.json({ plan: plan.data, model });
  } catch (error) {
    console.error("Planning request failed", error);
    return NextResponse.json({ error: "planning_failed", message: "حدث خطأ أثناء الاتصال بمحرك الذكاء." }, { status: 500 });
  }
}
