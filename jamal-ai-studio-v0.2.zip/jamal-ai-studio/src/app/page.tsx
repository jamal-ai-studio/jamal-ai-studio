"use client";

import { useRef, useState } from "react";
import {
  Activity, ArrowUp, Bot, Check, ChevronDown, CircleHelp, Code2, FileCode2,
  FolderGit2, Gauge, Github, Layers3, LockKeyhole, Paperclip, Plus, Settings2,
  ShieldCheck, Sparkles, TerminalSquare, WandSparkles, Workflow, Zap
} from "lucide-react";

type Plan = {
  title: string;
  summary: string;
  steps: { title: string; description: string; tool?: string; approvalRequired: boolean }[];
  questions: string[];
};

const quickPrompts = [
  { label: "أنشئ موقعاً إلكترونياً", prompt: "أنشئ موقعاً إلكترونياً احترافياً ومتجاوباً يحقق الفكرة التالية: " },
  { label: "افهم مستودع GitHub", prompt: "حلّل مستودع GitHub التالي واشرح بنيته وأهم الملفات والمشاكل المحتملة: " },
  { label: "ابنِ تطبيقاً", prompt: "خطط لبناء تطبيق متكامل للفكرة التالية، مع تقسيمه إلى مراحل واضحة: " },
];

const capabilities = [
  { icon: Github, title: "GitHub", detail: "قراءة المستودعات وإدارة التغييرات", state: "جاهز للربط" },
  { icon: TerminalSquare, title: "Terminal / Worker", detail: "تشغيل أوامر داخل بيئة معزولة", state: "مرحلة قادمة" },
  { icon: Code2, title: "Code Agent", detail: "إنشاء الملفات وتعديل الكود", state: "مرحلة قادمة" },
  { icon: Layers3, title: "Tool Registry", detail: "إضافة الأدوات وربطها", state: "قابل للتوسعة" },
];

export default function Home() {
  const [prompt, setPrompt] = useState("");
  const [plan, setPlan] = useState<Plan | null>(null);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const [model, setModel] = useState("");
  const [fileNames, setFileNames] = useState<string[]>([]);
  const fileRef = useRef<HTMLInputElement>(null);

  async function makePlan() {
    if (prompt.trim().length < 4 || busy) return;
    setBusy(true);
    setError("");
    setPlan(null);
    try {
      const res = await fetch("/api/plan", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ prompt: prompt.trim() })
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.message || "تعذر إعداد الخطة.");
      setPlan(data.plan);
      setModel(data.model || "");
    } catch (e) {
      setError(e instanceof Error ? e.message : "حدث خطأ غير متوقع.");
    } finally {
      setBusy(false);
    }
  }

  return (
    <main className="min-h-screen">
      <header className="sticky top-0 z-30 border-b border-slate-200/80 bg-white/90 backdrop-blur-xl">
        <div className="mx-auto flex h-[72px] max-w-[1440px] items-center justify-between px-4 sm:px-6">
          <div className="flex items-center gap-3">
            <div className="grid h-10 w-10 place-items-center rounded-2xl bg-gradient-to-br from-indigo-600 to-violet-500 text-white shadow-lg shadow-indigo-200"><Sparkles size={20}/></div>
            <div>
              <div className="text-[15px] font-extrabold tracking-tight text-slate-900">Jamal AI Studio</div>
              <div className="text-[11px] text-slate-500">مساحة العمل الذكية الخاصة بك</div>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <span className="hidden items-center gap-1.5 rounded-full border border-emerald-200 bg-emerald-50 px-3 py-1.5 text-xs font-semibold text-emerald-700 sm:inline-flex"><span className="h-1.5 w-1.5 rounded-full bg-emerald-500"/> وضع التخطيط الآمن</span>
            <button className="grid h-10 w-10 place-items-center rounded-xl border border-slate-200 text-slate-600 hover:bg-slate-50" aria-label="الإعدادات"><Settings2 size={18}/></button>
          </div>
        </div>
      </header>

      <div className="mx-auto grid max-w-[1440px] gap-6 px-4 py-6 sm:px-6 lg:grid-cols-[minmax(0,1fr)_310px] lg:gap-8 lg:py-9">
        <section className="min-w-0">
          <div className="mb-7">
            <div className="mb-3 inline-flex items-center gap-2 rounded-full border border-indigo-100 bg-indigo-50 px-3 py-1.5 text-xs font-bold text-indigo-700"><WandSparkles size={14}/> مساعدك البرمجي المستقل</div>
            <h1 className="text-3xl font-black leading-tight tracking-tight text-slate-950 sm:text-[42px]">ماذا تريد أن <span className="bg-gradient-to-l from-indigo-600 to-violet-500 bg-clip-text text-transparent">نبني اليوم؟</span></h1>
            <p className="mt-3 max-w-2xl text-sm leading-7 text-slate-500 sm:text-base">اكتب فكرتك بلغتك، وسأحوّلها إلى خطة عمل واضحة. نبدأ بالتخطيط، ثم نضيف قدرات قراءة المشاريع وتعديل الكود وتشغيله بأمان.</p>
          </div>

          <div className="rounded-[28px] border border-slate-200 bg-white p-3 shadow-[0_18px_60px_-38px_rgba(15,23,42,.28)] sm:p-5">
            <div className="flex items-center justify-between px-2 pb-2">
              <label htmlFor="task" className="text-sm font-bold text-slate-800">اكتب تعليماتك</label>
              <span className="text-[11px] text-slate-400">يدعم اللغة العربية</span>
            </div>
            <textarea id="task" value={prompt} onChange={e => setPrompt(e.target.value)} placeholder="مثلاً: أريد بناء متجر إلكتروني متكامل، اربطه بقاعدة بيانات ولوحة تحكم، واشرح لي خطة التنفيذ..." className="min-h-[170px] w-full resize-y rounded-2xl border border-slate-100 bg-slate-50/80 p-4 text-[14px] leading-8 text-slate-800 outline-none transition placeholder:text-slate-400 focus:border-indigo-300 focus:bg-white focus:ring-4 focus:ring-indigo-50"/>
            {fileNames.length > 0 && <div className="mt-3 flex flex-wrap gap-2">{fileNames.map(n => <span key={n} className="rounded-lg bg-slate-100 px-2.5 py-1 text-xs text-slate-600">{n}</span>)}</div>}
            <div className="mt-3 flex flex-wrap items-center justify-between gap-3">
              <div className="flex items-center gap-2">
                <button onClick={() => fileRef.current?.click()} className="inline-flex items-center gap-2 rounded-xl border border-slate-200 px-3 py-2.5 text-xs font-semibold text-slate-600 transition hover:bg-slate-50"><Paperclip size={15}/> إرفاق ملفات</button>
                <input ref={fileRef} type="file" multiple className="hidden" onChange={e => setFileNames(Array.from(e.target.files || []).map(f => f.name))}/>
                <span className="hidden text-[11px] text-slate-400 sm:inline">المرفقات في هذه النسخة للعرض فقط</span>
              </div>
              <button onClick={makePlan} disabled={busy || prompt.trim().length < 4} className="inline-flex items-center gap-2 rounded-xl bg-indigo-600 px-5 py-3 text-sm font-bold text-white shadow-lg shadow-indigo-200 transition hover:bg-indigo-700 disabled:shadow-none">
                {busy ? <><Activity size={16} className="animate-pulse"/> جارٍ التحليل...</> : <>حلّل المهمة <ArrowUp size={17}/></>}
              </button>
            </div>
          </div>

          <div className="mt-4 flex flex-wrap gap-2">
            {quickPrompts.map(q => <button key={q.label} onClick={() => setPrompt(q.prompt)} className="rounded-full border border-slate-200 bg-white px-3.5 py-2 text-xs font-semibold text-slate-600 transition hover:border-indigo-200 hover:bg-indigo-50 hover:text-indigo-700">{q.label}</button>)}
          </div>

          {error && <div className="mt-5 flex items-start gap-3 rounded-2xl border border-amber-200 bg-amber-50 p-4 text-sm leading-6 text-amber-900"><CircleHelp size={18} className="mt-0.5 shrink-0"/><div><strong>لم تكتمل العملية</strong><p>{error}</p></div></div>}

          {plan && <section className="mt-6 rounded-[26px] border border-indigo-100 bg-white p-5 shadow-sm sm:p-6">
            <div className="flex flex-wrap items-center justify-between gap-3">
              <div className="flex items-center gap-2 text-sm font-extrabold text-slate-900"><Workflow size={18} className="text-indigo-600"/> خطة التنفيذ المقترحة</div>
              {model && <span className="rounded-full bg-slate-100 px-3 py-1 text-[11px] text-slate-500">النموذج: {model}</span>}
            </div>
            <h2 className="mt-4 text-xl font-extrabold text-slate-900">{plan.title}</h2>
            <p className="mt-2 text-sm leading-7 text-slate-600">{plan.summary}</p>
            <div className="mt-5 space-y-3">
              {plan.steps.map((step, i) => <div key={`${step.title}-${i}`} className="flex gap-3 rounded-2xl border border-slate-100 bg-slate-50/70 p-3.5">
                <span className="grid h-8 w-8 shrink-0 place-items-center rounded-xl bg-indigo-100 text-xs font-black text-indigo-700">{i + 1}</span>
                <div className="min-w-0 flex-1"><div className="font-bold text-slate-800">{step.title}</div><p className="mt-1 text-xs leading-6 text-slate-500">{step.description}</p>{step.tool && <span className="mt-2 inline-block rounded-md bg-white px-2 py-1 text-[10px] text-slate-500">الأداة المقترحة: {step.tool}</span>}</div>
                {step.approvalRequired && <span className="h-fit shrink-0 rounded-full bg-amber-50 px-2 py-1 text-[10px] font-bold text-amber-700">تحتاج موافقة</span>}
              </div>)}
            </div>
            {plan.questions.length > 0 && <div className="mt-4 rounded-xl bg-violet-50 p-4"><div className="mb-2 text-xs font-extrabold text-violet-800">أسئلة لتوضيح المطلوب</div>{plan.questions.map((q,i)=><p key={i} className="text-xs leading-6 text-violet-700">• {q}</p>)}</div>}
            <div className="mt-5 flex items-center gap-2 rounded-xl border border-emerald-100 bg-emerald-50 p-3 text-xs leading-6 text-emerald-800"><ShieldCheck size={16} className="shrink-0"/> هذه خطة فقط. لم يتم تعديل ملفات أو تشغيل أوامر أو الاتصال بـ GitHub.</div>
          </section>}

          <div className="mt-8">
            <div className="mb-3 flex items-center justify-between"><h2 className="font-extrabold text-slate-900">مساحة العمل</h2><button className="text-xs font-semibold text-indigo-600">عرض الكل <ChevronDown size={13} className="inline"/></button></div>
            <div className="grid gap-3 sm:grid-cols-2">
              <div className="rounded-2xl border border-slate-200 bg-white p-4"><div className="flex items-center gap-2 text-sm font-bold text-slate-800"><FolderGit2 size={17} className="text-indigo-600"/> مشاريعي</div><p className="mt-2 text-xs leading-6 text-slate-500">ستظهر هنا مستودعاتك ومشاريعك بعد ربط GitHub.</p></div>
              <div className="rounded-2xl border border-slate-200 bg-white p-4"><div className="flex items-center gap-2 text-sm font-bold text-slate-800"><FileCode2 size={17} className="text-emerald-600"/> الملفات والنتائج</div><p className="mt-2 text-xs leading-6 text-slate-500">مكان موحد لملفات المشاريع ومخرجات المهام.</p></div>
            </div>
          </div>
        </section>

        <aside className="space-y-4">
          <div className="rounded-[26px] border border-slate-200 bg-white p-5 shadow-sm">
            <div className="flex items-center justify-between"><h2 className="font-extrabold text-slate-900">قدرات المنصة</h2><span className="rounded-full bg-indigo-50 px-2.5 py-1 text-[10px] font-bold text-indigo-700">Open models</span></div>
            <p className="mb-4 mt-1 text-xs leading-6 text-slate-500">هذه وحدات النظام التي سنربطها تدريجياً.</p>
            <div className="space-y-3">
              {capabilities.map(({icon: Icon,title,detail,state}) => <div key={title} className="flex items-start gap-3 rounded-2xl bg-slate-50 p-3">
                <div className="grid h-9 w-9 shrink-0 place-items-center rounded-xl bg-white text-indigo-600 shadow-sm"><Icon size={17}/></div>
                <div className="min-w-0 flex-1"><div className="text-sm font-bold text-slate-800">{title}</div><div className="mt-0.5 text-[11px] leading-5 text-slate-500">{detail}</div><div className="mt-1 text-[10px] font-semibold text-slate-400">{state}</div></div>
              </div>)}
            </div>
            <button disabled className="mt-4 w-full rounded-xl border border-dashed border-slate-300 py-2.5 text-xs font-semibold text-slate-500"><Plus size={14} className="ml-1 inline"/> إضافة أداة لاحقاً</button>
          </div>

          <div className="rounded-[26px] border border-slate-200 bg-gradient-to-br from-white to-indigo-50/70 p-5">
            <div className="flex items-center gap-2 font-extrabold text-slate-900"><Bot size={18} className="text-indigo-600"/> محرك الذكاء</div>
            <p className="mt-2 text-xs leading-6 text-slate-600">يدعم أي مزود متوافق مع واجهة OpenAI API ويمكن تشغيل نماذج مفتوحة الأوزان مثل Qwen أو Llama أو DeepSeek عبر مزود مستضاف أو خادم خاص.</p>
            <div className="mt-3 flex items-center gap-2 rounded-xl bg-white/80 p-3 text-[11px] text-slate-600"><Zap size={15} className="text-amber-500"/> لا يعتمد على Claude Code</div>
          </div>

          <div className="rounded-[26px] bg-slate-950 p-5 text-white">
            <div className="flex items-center gap-2 font-bold"><LockKeyhole size={17} className="text-emerald-400"/> التنفيذ الآمن</div>
            <p className="mt-2 text-xs leading-6 text-slate-300">لن نسمح بتنفيذ أكواد أو أوامر عشوائية على خادم الموقع. كل تنفيذ لاحق سيكون داخل عامل معزول وبصلاحيات محدودة، مع موافقتك قبل التغييرات الحساسة.</p>
            <div className="mt-4 flex items-center gap-2 text-[10px] font-semibold text-emerald-300"><ShieldCheck size={14}/> الموافقة قبل التأثير الخارجي</div>
          </div>
        </aside>
      </div>

      <footer className="mx-auto flex max-w-[1440px] flex-wrap items-center justify-between gap-2 px-4 pb-7 text-[11px] text-slate-400 sm:px-6">
        <span>Jamal AI Studio · نسخة تأسيسية قيد التطوير</span>
        <span className="flex items-center gap-1"><Gauge size={13}/> واجهة تجريبية — ليست منشورة بعد</span>
      </footer>
    </main>
  );
}
