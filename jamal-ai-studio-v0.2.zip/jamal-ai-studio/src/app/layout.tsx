import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "Jamal AI Studio",
  description: "استوديو ذكي لبناء المشاريع والبرمجة وتنفيذ المهام بمساعدتك"
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="ar" dir="rtl"><body>{children}</body></html>;
}
