# Jamal AI Studio — Architecture

## Product direction
A self-hostable, Arabic-first coding agent. The model provider is replaceable; the product does not depend on Claude Code.

## Current vertical slice
Browser UI -> Next.js `/api/plan` -> server-side OpenAI-compatible inference endpoint -> validated JSON plan -> UI.
The route is planning-only. It does not execute tools, write files, or access GitHub.

## Target execution lifecycle
1. Authenticate the user.
2. Receive prompt and authorized project context.
3. Planner proposes a typed plan.
4. Policy engine classifies each action and required permissions.
5. Persist approval for an immutable action payload and version.
6. Revalidate user, approval, expiry, policy, and payload hash server-side.
7. Dispatch an allowlisted tool to an isolated worker.
8. Stream logs and task events to the UI.
9. Store outputs and audit events.

## Target modules
- Model Gateway: OpenAI-compatible endpoint adapter; model selection and quotas.
- Planner: structured plans and clarification questions.
- Project Context: GitHub repository reader with minimum OAuth scopes.
- Tool Registry: signed/versioned tool manifests, schemas, risk classes.
- Approval Engine: approval bound to immutable payload hash.
- Worker: isolated containers, non-root, read-only base image, CPU/RAM/time quotas, network allowlist.
- Artifact Store: user-owned uploads and generated files.
- Audit: append-only events, retention, cost and usage metering.

## Security
Never execute untrusted repositories, shell commands, or MCP servers in the Next.js process. Do not accept arbitrary inference base URLs from browser requests; configure them only in server environment. Keep API keys server-side. Treat all repository content as untrusted input, not instructions.
