# Master prompt for Claude Code

You are the senior full-stack engineer implementing AI Command Studio from this repository.

## Product
Build an Arabic-first, responsive, online AI workspace. Users describe tasks in natural Arabic, attach files, receive a structured plan, review exact proposed actions, approve them, and then see execution progress and results.

## Non-negotiable rules
1. Inspect the existing repository before changing anything.
2. Preserve the current architecture unless there is a concrete reason to change it.
3. Never claim a feature is implemented unless it works.
4. Never expose secrets in client bundles, logs, source control, or error messages.
5. All user data must be isolated by authenticated user ID and protected by RLS.
6. All writes, external API calls, compute jobs, repository changes, and paid operations require explicit approval.
7. Approval must bind to an immutable action payload hash and expire.
8. Revalidate approval server-side immediately before execution.
9. Do not implement arbitrary shell execution or arbitrary GitHub repository execution in the web app.
10. Build tests for authorization, approval bypass attempts, invalid inputs, and failure paths.

## MVP scope, in order
A. Polish and complete the Arabic RTL dashboard.
B. Implement Supabase SSR authentication and protected routes.
C. Implement database access for projects, tasks, task events, approvals, and assets.
D. Implement a provider-neutral AI interface with at least one configurable provider; keep provider keys server-side.
E. Implement structured task planning with schema validation. Planning must not execute tools.
F. Implement approval creation, review, approve/reject, expiry, and immutable payload hashes.
G. Implement a safe tool registry with mock tools first.
H. Implement a worker contract and authenticated queue interface; do not pretend a worker exists until deployed.
I. Add upload validation, storage policies, file-size limits, and safe file handling.
J. Add automated tests and deployment documentation.

## AI provider strategy
Use a provider adapter interface. Support OpenAI, Anthropic, and Google as future adapters, but do not force all three into the first release. Select a low-cost model by environment configuration. Add timeouts, token limits, rate limits, and graceful errors. Never silently switch providers if that would send user data to a different provider; ask for user-configured consent.

## Tool execution
Start with mock tools and a clear `not_configured` state. Later tools must be allowlisted and run only in a separately deployed sandboxed worker. Use MCP only through a controlled server-side gateway with explicit per-tool permissions. Do not accept arbitrary MCP server URLs from untrusted clients.

## Remotion
Treat Remotion as a separate rendering worker. The web app may create a render job after approval, but rendering must happen outside the Next.js request process. Add an explicit worker health state and never claim MP4 export works until an actual render worker is configured and tested.

## UI requirements
- Arabic RTL default, mobile-first.
- Sidebar/navigation: المحادثة، المشاريع، المهام، الموافقات، الأدوات، الملفات، الإعدادات.
- Chat composer supports attachments and clear upload state.
- Task plan has numbered steps, status, selected tools, and estimated cost when known.
- Approval center displays exact actions, permissions, cost, expiry, and approve/reject controls.
- Execution timeline shows events and errors.
- Empty, loading, error, and disconnected states must be designed.
- Avoid fake success states and decorative controls that do nothing.

## Deliverables
1. Working code.
2. SQL migrations and RLS policies.
3. `.env.example` with no real secrets.
4. Tests.
5. README with exact local setup.
6. Deployment guide for Vercel + Supabase + worker.
7. A list of unfinished integrations and required credentials.

## Workflow
- First inspect files and report a short implementation plan.
- Implement in small coherent stages.
- Run typecheck, lint, tests, and production build.
- Fix errors before finishing.
- At the end, report what is actually working, what is mocked, what credentials are needed, and exact next steps.
