# Deployment checklist

## Supabase
1. Create a Supabase project.
2. Run `supabase/schema.sql` in the SQL editor.
3. Configure Auth redirect URLs for local and production domains.
4. Create a private storage bucket for user assets and add per-user path policies.
5. Add URL and anon key to hosting environment variables.
6. Keep service-role key server-only.

## Vercel
1. Import the GitHub repository.
2. Set environment variables from `.env.example`.
3. Deploy the Next.js app.
4. Configure custom domain and Supabase redirect URLs.

## Worker (separate host)
1. Deploy a worker service in a container-capable environment.
2. Authenticate queue messages with a rotating secret or signed service identity.
3. Run tools in ephemeral containers with CPU/memory/time limits.
4. Add network egress allowlists and object-storage access scoped per task.
5. Configure Remotion rendering and test a short sample MP4.
6. Monitor worker health, queue depth, failures, and costs.

## Before public launch
- Enable rate limits and quotas.
- Add malware scanning for uploaded files.
- Add content-type and size validation.
- Add account deletion and data export.
- Define retention periods.
- Add audit logs and incident response procedures.
