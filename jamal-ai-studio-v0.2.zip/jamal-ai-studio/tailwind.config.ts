import type { Config } from "tailwindcss";
const config: Config = {
  content: ["./src/**/*.{js,ts,jsx,tsx,mdx}"],
  theme: { extend: {
    colors: {
      ink: "#171717",
      muted: "#737373",
      panel: "#ffffff",
      canvas: "#f6f7f9",
      brand: "#6558d3"
    },
    boxShadow: { soft: "0 12px 40px rgba(20,20,40,.06)" }
  }},
  plugins: []
};
export default config;
