-- Apply in Supabase SQL Editor. RLS is enabled on every user-owned table.
create extension if not exists pgcrypto;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  display_name text,
  created_at timestamptz not null default now()
);

create table if not exists public.projects (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  name text not null,
  description text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.tasks (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  project_id uuid references public.projects(id) on delete set null,
  title text not null,
  user_prompt text not null,
  status text not null default 'draft'
    check (status in ('draft','planned','awaiting_approval','queued','running','succeeded','failed','cancelled')),
  plan jsonb not null default '[]'::jsonb,
  result jsonb,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.tool_connections (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  tool_id text not null,
  display_name text not null,
  connection_type text not null check (connection_type in ('oauth','api_key','mcp','webhook')),
  status text not null default 'disconnected' check (status in ('connected','disconnected','error')),
  secret_reference text, -- reference to an external secrets vault; never store plaintext secrets here
  configuration jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now(),
  unique(user_id, tool_id)
);

create table if not exists public.approval_requests (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  task_id uuid not null references public.tasks(id) on delete cascade,
  action_summary text not null,
  action_payload jsonb not null,
  risk_level text not null check (risk_level in ('low','medium','high')),
  estimated_cost numeric(12,4),
  status text not null default 'pending' check (status in ('pending','approved','rejected','expired')),
  approved_at timestamptz,
  expires_at timestamptz,
  created_at timestamptz not null default now()
);

create table if not exists public.task_events (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  task_id uuid not null references public.tasks(id) on delete cascade,
  event_type text not null,
  message text not null,
  metadata jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);

create table if not exists public.assets (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  task_id uuid references public.tasks(id) on delete set null,
  storage_path text not null,
  original_name text not null,
  mime_type text,
  size_bytes bigint,
  created_at timestamptz not null default now()
);

alter table public.profiles enable row level security;
alter table public.projects enable row level security;
alter table public.tasks enable row level security;
alter table public.tool_connections enable row level security;
alter table public.approval_requests enable row level security;
alter table public.task_events enable row level security;
alter table public.assets enable row level security;

create policy "profile owner read" on public.profiles for select using (auth.uid() = id);
create policy "profile owner update" on public.profiles for update using (auth.uid() = id);
create policy "projects owner all" on public.projects for all using (auth.uid() = user_id) with check (auth.uid() = user_id);
create policy "tasks owner all" on public.tasks for all using (auth.uid() = user_id) with check (auth.uid() = user_id);
create policy "connections owner all" on public.tool_connections for all using (auth.uid() = user_id) with check (auth.uid() = user_id);
create policy "approvals owner all" on public.approval_requests for all using (auth.uid() = user_id) with check (auth.uid() = user_id);
create policy "events owner select" on public.task_events for select using (auth.uid() = user_id);
create policy "assets owner all" on public.assets for all using (auth.uid() = user_id) with check (auth.uid() = user_id);

create index if not exists tasks_user_created_idx on public.tasks(user_id, created_at desc);
create index if not exists events_task_created_idx on public.task_events(task_id, created_at asc);
create index if not exists approvals_user_status_idx on public.approval_requests(user_id, status);
